﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Threading;

//Name: Max Chan
//Date: May 27 2022 to June 10 2022
//Purpose: To create an error free locker system that inputs and updates values of students names, ID, and locker number. 

namespace LockerSystem
{
    class Program
    {
        static void Main(string[] args)
        {
            string answer = null; 

            StreamReader reader = new StreamReader(@"data.txt");
            int ArrLength = 0;

            string Loop = reader.ReadLine();
            try //if the code is able to locate data.txt file it will read the first line and taking it as arr length
            {
                ArrLength = int.Parse(Loop);
            }
            catch //if the code cant find the file it will load this message
            {
                Console.WriteLine("File may have no data, or 0 array length. Check to see if file empty, if is add atleast one piece of information beginning at 1");
                Console.ReadKey();
            }
            string info;

            //these are all variables I set

            string[] LockerNum = new string[ArrLength];
            string[] Surname = new string[ArrLength];
            string[] FirstName = new string[ArrLength];
            string[] StudentID = new string[ArrLength];
            //declaring arrays which set array length based off the first number in data.txt

            //declare another variable
            for (int i = 0; i < ArrLength; i++)
            {
                info = reader.ReadLine();

                string[] Studentinfo = info.Split(';');
                   
                LockerNum[i] = Studentinfo[0];
                Surname[i] = Studentinfo[1];
                FirstName[i] = Studentinfo[2];
                StudentID[i] = Studentinfo[3];
            }
            reader.Close();
            do // executes code before checking condition 
            {
                Console.WriteLine("Welcome to BR Locker System\n"); //Console writes messages that make the program user friendly and easy to follow
                {
                    Console.WriteLine("What would you like to do?\n");
                    Console.WriteLine("1. Input's Student Information");
                    Console.WriteLine("2. Update");
                    Console.WriteLine("3. Display Current Record");
                    Console.WriteLine("4. Search");
                    Console.WriteLine("5. Quit");
                    int i = 0; //i = 0 allows the user to input any value
                    do // executes code before checking condition
                    {
                        try //executes code, if cannot find a numeric value, catch will execute
                        {
                            Console.Write("Which Menu would you like to open? : ");
                            i = int.Parse(Console.ReadLine()); // user inputs a value for i that determines which menu will execute
                            while (i > 5) //if i value is less than 5, the following code will execute
                            {
                                Console.WriteLine("Please enter a value from 1-5");
                                Console.WriteLine("Which Menu would you like to open?");
                                i = int.Parse(Console.ReadLine()); //i value inputted by user will determine which menu executes (1, 2, 3, 4, 5)
                            }
                        }
                        catch (Exception) //catches any value that isnt of a numeric value
                        {
                            Console.WriteLine("Please enter a numeric value!");
                            i = 0; // i = 0 so that the user is able to input new values
                        }
                    }
                    while (i == 0); //if i = 0, the do while loop will execute again

                    int number = 0; //declare variable
                    int index = 0; //declare variable

                    if (i == 1) //if user input is i=1, the following block will execute
                    {
                            
                        bool Add = false; //bool statement
                        int k = 0; //declare variable

                        do // executes code before checking condition
                        {
                            number = 0; //declare variable
                            do // executes code before checking condition
                            {

                                try //executes code, if cannot find a numeric value, catch will execute
                                {
                                    Console.Write("How many students would you like to register? : ");
                                    number = int.Parse(Console.ReadLine()); //number is converted to its 32 bit integer equivalent
                                }
                                catch (Exception) //catches any value that isnt of a numeric value
                                {
                                    Console.WriteLine("Please enter a numeric value!");
                                }
                            }
                            while (number == 0); // if number = 0, the do while will execute again

                            bool yes = true;
                            bool count = false;

                            if (count == true)
                            {
                                number = 0; //declare variable
                                do // executes code before checking condition 
                                {
                                    try //executes code, if cannot find a numeric value, catch will execute
                                    {
                                        Console.Write("How many students would you like to register? : ");
                                        number = int.Parse(Console.ReadLine()); //number is converted to its 32 bit integer equivalent
                                    }
                                    catch (Exception)
                                    {
                                        Console.WriteLine("Please enter a numeric value!");
                                    }
                                }
                                while (number == 0);
                            }

                            string[] LockerNumber2 = new string[ArrLength];
                            string[] Surname2 = new string[ArrLength];
                            string[] FirstName2 = new string[ArrLength];
                            string[] StudentID2 = new string[ArrLength];


                            for (index = 0; index < ArrLength; index++)
                            {
                                LockerNumber2[index] = LockerNum[index];//this makes sure that both arrays are equal
                                Surname2[index] = Surname[index];
                                FirstName2[index] = FirstName[index];
                                StudentID2[index] = StudentID[index];

                            }

                            LockerNum = new string[ArrLength + number];//this updates the array with the amount of data the user wants to input
                            Surname = new string[ArrLength + number];
                            FirstName = new string[ArrLength + number];
                            StudentID = new string[ArrLength + number];

                            for (index = 0; index < ArrLength; index++)
                            {
                                LockerNum[index] = LockerNumber2[index];//Finally it makes the 2 arrays equal storing all the information
                                Surname[index] = Surname2[index];
                                FirstName[index] = FirstName2[index];
                                StudentID[index] = StudentID2[index];

                            }
                            for (index = (ArrLength); index < (number + ArrLength); index++)
                            {

                                do // executes code before checking condition
                                {
                                    try //executes code, if cannot find a numeric value, catch will execute
                                    {
                                        k++; // k value increases each time the code loops
                                        Console.WriteLine("Record #" + k); // k value increases by 1 as the code loops
                                        do // executes code before checking condition
                                        {
                                            try //executes code, if cannot find a numeric value, catch will execute
                                            {
                                                Console.Write("Locker Number (Only up to 4 digits): ");
                                                LockerNum[index] = Console.ReadLine();
                                                int.Parse(LockerNum[index]);

                                                if (LockerNum[index].Length == 4) //if the length of numbers is = 4, the following block will occur. StudentID[index].Length==4 means the input must be no more or less than 4 integers
                                                {
                                                    break; // the loop is terminated and the program resumes at the following loop
                                                }
                                                else
                                                {
                                                    Console.WriteLine("Error - Locker Number must be no more than 4 digits");
                                                    yes = true; // if yes = true the do while loop will execute again
                                                }
                                            }
                                            catch // catches any entries that are not number values/valid integers
                                            {
                                                Console.WriteLine("Your Locker Number means Numbers only!");
                                                yes = true; // if yes = true the do while loop will execute again
                                            }
                                        }
                                        while (yes == true); // if the bool statement is true, the do while loop will execute

                                        Console.Write("Surname: ");
                                        Surname[index] = Console.ReadLine(); // user inputs surname and is stored in array
                                        Console.Write("First Name: ");
                                        FirstName[index] = Console.ReadLine(); // user inputs username and is stored in array

                                        do // executes code before checking condition
                                        {
                                            try
                                            {
                                                Console.Write("Student ID: ");
                                                StudentID[index] = Console.ReadLine();
                                                int.Parse(StudentID[index]);

                                                if (StudentID[index].Length == 9) //if the length of numbers is = 9, the following block will occur. StudentID[index].Length==9 means the input must be no more or less than 9 integers
                                                {
                                                    break; // the loop is terminated and the program resumes at the following loop
                                                }
                                                else
                                                {
                                                    Console.WriteLine("Error - Number must be no more or less than 9 integers");
                                                    yes = true; // if yes = true the do while loop will execute again
                                                }
                                            }
                                            catch // catches any entries that are not number values/valid integers
                                            {
                                                Console.WriteLine("Error - A valid integer must be entered");
                                                yes = true;
                                            }
                                        }
                                        while (yes == true);

                                        yes = false;
                                    }
                                    catch (Exception) // catches any entries that are not number values/valid integers
                                    {
                                        Console.WriteLine("Error - That is not a valid integer.\nEnter a new value: \n");
                                        yes = true; // if yes = true the do while loop will execute again
                                    }
                                }
                                while (yes == true);
                            }
                            ArrLength += number;

                            StreamWriter sw = new StreamWriter(@"data.txt");
                            sw.WriteLine(ArrLength);
                            for (index = 0; index < ArrLength; index++)
                            {
                                sw.WriteLine(LockerNum[index] + ";" + Surname[index] + ";" + FirstName[index] + ";" + StudentID[index] + ";");
                            }
                            sw.Close();
                            /*for (index = 0; index < number; index++)
                            {
                                sw.Write(LockerNum[index] + ";");
                                sw.Write(Surname[index] + ";");
                                sw.Write(FirstName[index] + ";");
                                sw.WriteLine(StudentID[index] + ";");
                            }*/
                            bool ye = false; // declare bool statement
                            do // executes code before checking condition
                            {
                                Console.Write("Would you like to add more students? (y/n) : ");
                                string addition = Console.ReadLine();
                                if (addition == "n")
                                {
                                    Add = false;
                                    ye = true;
                                }
                                else if (addition != "n" && addition != "y")
                                {
                                    Console.WriteLine("Please enter Y/N");
                                    ye = false;
                                }
                                else if (addition == "y" || addition == "Y")
                                {
                                    Console.WriteLine("\nSounds good!");
                                    Add = true;
                                    count = true;
                                    ye = true;
                                }
                            }
                            while (ye == false);
                        }
                        while (Add == true);
                    }
                    else if (i == 2)
                    {
                        Console.Clear(); //clears everything on screen
                        Console.Write("Please enter your search parameters : ");
                        string search = Console.ReadLine();
                        StreamReader sr = new StreamReader("data.txt");
                        string line;
                        while ((line = sr.ReadLine()) != null)
                        {
                            if (line.Contains(search))
                            {
                                string[] LineOne = line.Split(';');
                                Console.WriteLine("\n\t\t\t\t\tLocker Information System");
                                Console.WriteLine("\nLocker\t\t\tSurname\t\t\tFirst Name\t\t\tStudent ID");
                                Console.WriteLine("------\t\t\t-------\t\t\t---------\t\t\t-------------");
                                Console.WriteLine(" " + LineOne[0] + "\t\t\t" + LineOne[1] + "\t\t\t" + LineOne[2] + "\t\t\t\t" + LineOne[3]);
                            }
                        }
                        sr.Close();

                        bool update = false;

                        do // executes code before checking condition
                        {
                            Console.WriteLine("Would you like to update this record? (y/n) : ");
                            answer = Console.ReadLine();
                            if (answer == "n")
                            {
                                update = true;
                                break; // the loop is terminated and the program resumes at the following loop
                            }
                            else if (answer != "n" && answer != "y")
                            {
                                Console.WriteLine("Please enter Y/N");
                                update = false;
                            }
                            else if (answer == "y" || answer == "Y")
                            {
                                Console.WriteLine("\nSounds good!");
                                update = true;
                            }
                        }
                        while (update != true);

                        if (answer == "y" || answer == "Y")
                        {
                            Console.WriteLine("What do want to update?");
                            string OldText = Console.ReadLine();
                            Console.WriteLine("What do you want to replace it with?");
                            string NewText = Console.ReadLine();
                            string text = File.ReadAllText("data.txt");
                            text = text.Replace(OldText, NewText);
                            File.WriteAllText("data.txt", text);
                        }
                    }
                    else if (i == 3)
                    {
                        Console.Clear(); //clears everything on screen
                        if (new FileInfo("data.txt").Length == 0)
                        {
                            Console.Clear(); //clears everything on screen
                            Console.WriteLine("\t\tNo Information Available to Display!");
                            Thread.Sleep(1500); //pause before code continues
                            Console.WriteLine(".......");
                            Thread.Sleep(500); //pause before code continues
                            Console.WriteLine("\t\tClosing Locker System!");
                            Thread.Sleep(1000); //pause before code continues
                            Environment.Exit(0); //code ends
                        }
                        else
                        {
                            Console.Clear(); //clears everything on screen
                            Console.WriteLine("\n\t\t\t\t\tLocker Information System");
                            Console.WriteLine("\nLocker\t\t\tSurname\t\t\tFirst Name\t\t\tStudent ID");
                            Console.WriteLine("------\t\t\t-------\t\t\t---------\t\t\t-------------");
                            StreamReader sr = new StreamReader("data.txt"); // reopens text file
                            string line; // declares variable
                            line = sr.ReadLine(); // streamreader reads each line

                            while ((line = sr.ReadLine()) != null)
                            {
                                string[] Lines = line.Split(';'); // splits each line from ";"
                                Console.WriteLine(" " + Lines[0] + "\t\t\t" + Lines[1] + "\t\t\t" + Lines[2] + "\t\t\t\t" + Lines[3]); // displays the arrays seperated 
                            }
                            sr.Close();
                        }
                    }
                    else if (i == 4)
                    {
                        Console.Clear(); //clears everything on screen
                        Console.WriteLine("Please enter your search parameters: ");
                        string search = Console.ReadLine();
                        StreamReader sr = new StreamReader("data.txt");
                        string line;
                        while ((line = sr.ReadLine()) != null)
                        {
                            if (line.Contains(search)) //searches for any lines that contains the value inputted by string search
                            {
                                string[] LineOne = line.Split(';'); //splits the 
                                Console.WriteLine("\n\t\t\t\t\tLocker Information System");
                                Console.WriteLine("\nLocker\t\t\tSurname\t\t\tFirstName\t\t\tStudent ID");
                                Console.WriteLine("------\t\t\t-------\t\t\t---------\t\t\t-------------");
                                Console.WriteLine(" " + LineOne[0] + "\t\t\t" + LineOne[1] + "\t\t\t" + LineOne[2] + "\t\t\t\t" + LineOne[3]);
                            }
                        }
                        sr.Close();
                    }
                    else if (i == 5)
                    {
                        Console.Clear(); //clears everything on screen
                        Console.WriteLine("\t\t\tClosing Locker System!");
                        Thread.Sleep(1000); //pause before code continues
                        Console.WriteLine("\n\n\t\t\t\tByeBye!");
                        Thread.Sleep(1000); //pause before code continues
                        Environment.Exit(0); //code ends
                    }
                    else
                    {
                        Console.WriteLine("Please input a value from 1 - 5");
                    }
                }
                bool back = false;
                do // executes code before checking condition
                {
                    Console.Write("\nWould you like to go back to the menu? (y/n) : "); //console gives user an option 
                    answer = Console.ReadLine(); //input decides which if/if else statement will execute
                    if (answer == "n" || answer == "N") // if the user inputs "n" or "N" the following code will execute
                    {
                        Console.WriteLine("\n\t\t\tExiting Application....");
                        Thread.Sleep(1000); //pause before code continues
                        Environment.Exit(0); //code ends
                    }
                    else if (answer != "n" && answer != "y" && answer != "N" && answer != "Y") //if the answer that the user inputs doesnt equal "n" and "y" or "N" or "Y", the block of code will execute
                    {
                        Console.WriteLine("Please enter Y/N"); //asks the user to input either Y/N
                        back = false; //bool is false, meaning that the do while loop is true and the do while will repeat
                    }
                    else if (answer == "y" || answer == "Y") //if the answer that the user inputs equals "y" OR "Y"
                    {
                        Console.WriteLine("\nSounds good!");
                        Thread.Sleep(1000); //pause before code continues
                        back = true; //bool is true, meaning that the do while loop will not repeat
                    }
                }
                while (back != true); // do while loop will only continue if back doesn't equal true
                Console.Clear();
            }
            while (answer == "y"); //if user answers "y" if they want to continue the code, the do while loop will repeat the code

            Console.ReadKey(); // allows the user to read the code
        }
    }
}